﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Remainder
    {
        public string rema;
        public double rem;
        public Remainder(string re)
        {
            rema = re;

            rem = DeclareVar.num1 % DeclareVar.num2;



        }
       
    }
}
