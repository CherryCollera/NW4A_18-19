﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Product
    {
        public string pro;
        public double prod;
        public Product(string pr)
        {

            pro = pr;
            prod = DeclareVar.num1 * DeclareVar.num2;



        }
     
    }
}
