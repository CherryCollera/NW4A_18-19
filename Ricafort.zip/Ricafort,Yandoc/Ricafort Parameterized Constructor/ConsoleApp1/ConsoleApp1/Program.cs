﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Input inp = new Input();
            inp.InputValue();

            DeclareVar dec = new DeclareVar();

            Sum s = new Sum("Sum ");
            System.Console.WriteLine(s.summ+" =" + s.sum);
            Console.ReadLine();

            Difference d = new Difference("Difference");
            System.Console.WriteLine(d.diffe+" =" + d.diff);
            Console.ReadLine();

           
            Product p = new Product("Product");
            System.Console.WriteLine(p.pro+" =" + p.prod);
            Console.ReadLine();



            Quotient q = new Quotient("Quotient");
            System.Console.WriteLine(q.quot+" =" + q.quo);
            Console.ReadLine();


            Remainder r = new Remainder("Remainder");
            System.Console.WriteLine(r.rema+" =" + r.rem);
            Console.ReadLine();


        }
    }
}
