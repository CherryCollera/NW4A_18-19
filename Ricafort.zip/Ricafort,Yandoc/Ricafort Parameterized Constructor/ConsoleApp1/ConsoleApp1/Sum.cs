﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Sum
    {
        public string summ;
 public double sum;
        public Sum(string su)
        {
            summ = su;
            sum = DeclareVar.num1 + DeclareVar.num2;



        }
       
    }
    }

