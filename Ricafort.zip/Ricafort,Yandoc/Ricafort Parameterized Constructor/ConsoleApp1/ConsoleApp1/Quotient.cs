﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Quotient
    {
        public string quot;
        public double quo;
        public Quotient(string qu)
        {

            quot = qu;
            quo = DeclareVar.num1 / DeclareVar.num2;



        }
       
    }
}
