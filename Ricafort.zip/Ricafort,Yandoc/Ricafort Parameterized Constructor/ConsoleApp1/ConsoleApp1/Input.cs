﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Input
    {
        public void InputValue()
        {
            try
            {
                System.Console.Write("Enter First Number: \t");
                DeclareVar.num1 = System.Convert.ToDouble(System.Console.ReadLine());
                System.Console.Write("Enter Second Number: \t");
                DeclareVar.num2 = System.Convert.ToDouble(System.Console.ReadLine());
            }
            catch (System.FormatException ex) //system error message
            {
                System.Console.Error.WriteLine("error:" + ex.Message);
                throw;
            }

            //catch (System.FormatException)//userdefined error
            //{
            //    System.Console.WriteLine("User Input is Invalid");
            //}
        }
    }
}
