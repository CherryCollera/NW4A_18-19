﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.Parameterized_Con
{
    class Program
    {
        private static void Main(string[] args)
        {
            Sample s = new Sample("Charlie", "Ricafort");

            Console.WriteLine(s.firstname);
            Console.WriteLine(s.lastname);
            Console.ReadLine();
        }
    }
}
