﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Static_Constructor.Static_Constructor
{
    class Sample
    {
        public string firstname, lastname;

        static Sample()
        {
            System.Console.WriteLine("Static Constructor");
        }
        public Sample()
        {
            firstname = "Charlie";
            lastname = "Ricafort";
        }
    }
}
