﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Private_Constructor.Private_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s = new Sample("Charlie", "Ricafort");
            Console.WriteLine(s.firstname + " " + s.lastname);
            Console.ReadLine();
        }
    }
}
