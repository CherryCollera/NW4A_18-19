﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lab3_Reborbhejay
{
	/// <summary>
	/// Description of Calculator.
	/// </summary>
	public partial class Calculator : Form
	{
		public Calculator()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
		
			//
		}
		
		
		void Bt0Click(object sender, EventArgs e)
		{
			answer.Text += "0";
		}
		void Bt1Click(object sender, EventArgs e)
		{
			answer.Text += "1";
		}
		void Bt2Click(object sender, EventArgs e)
		{
			answer.Text += "2";
		}
		void Bt3Click(object sender, EventArgs e)
		{
			answer.Text += "3";
		}
		void Bt4Click(object sender, EventArgs e)
		{	
			answer.Text += "4";
		}
		void Bt5Click(object sender, EventArgs e)
		{
			answer.Text += "5";
		}
		void Bt6Click(object sender, EventArgs e)
		{
			answer.Text += "6";
		}
		void Bt7Click(object sender, EventArgs e)
		{
			answer.Text += "7";
		}
		void Bt8Click(object sender, EventArgs e)
		{
			answer.Text += "8";
		}
		void Bt9Click(object sender, EventArgs e)
		{
			answer.Text += "9";
		}
		void NumPointClick(object sender, EventArgs e)
		{
			answer.Text += ".";
		}
		void BtnClearClick(object sender, EventArgs e)
		{
			answer.Clear();
			DeclareVar.total1 = 0;
			DeclareVar.total2 = 0;
		}
		
		void BtnPlusClick(object sender, EventArgs e)
		{
			DeclareVar.total1 = Convert.ToDouble(answer.Text);
		    answer.Clear();
		    DeclareVar.plusButtonClicked = true;
		}
		void BtnEqualsClick(object sender, EventArgs e)
		{
			if(DeclareVar.plusButtonClicked == true){
				DeclareVar.total1 += Convert.ToDouble(answer.Text);
				answer.Text = DeclareVar.total1.ToString();
			}
			
			if(DeclareVar.minusButtonClicked == true){
				DeclareVar.total1 -= Convert.ToDouble(answer.Text);
				answer.Text = DeclareVar.total1.ToString();
			}
			
			if(DeclareVar.divideButtonClicked == true){
				DeclareVar.total1 /= Convert.ToDouble(answer.Text);
				answer.Text = DeclareVar.total1.ToString();
			}
			
			if(DeclareVar.multiplyButtonClicked == true){
				DeclareVar.total1 *= Convert.ToDouble(answer.Text);
				answer.Text = DeclareVar.total1.ToString();
			}
			
			DeclareVar.minusButtonClicked = false;
			DeclareVar.plusButtonClicked = false;
			DeclareVar.multiplyButtonClicked = false;
			DeclareVar.divideButtonClicked =false;
		}
		void BtnSubClick(object sender, EventArgs e)
		{
			DeclareVar.total1 = Convert.ToDouble(answer.Text);
		    answer.Clear();
		    DeclareVar.minusButtonClicked = true;
		}
		void BtnMulClick(object sender, EventArgs e)
		{
			DeclareVar.total1 = Convert.ToDouble(answer.Text);
		    answer.Clear();
		    DeclareVar.multiplyButtonClicked = true;
		}
		void BtnDivClick(object sender, EventArgs e)
		{
			DeclareVar.total1 = Convert.ToDouble(answer.Text);
		    answer.Clear();
		    DeclareVar.divideButtonClicked = true;
		}
		
		
	}
}
