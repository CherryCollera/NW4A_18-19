﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PlusOne__StaticConstructor__Group_
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

  

        private void txtUser_Click(object sender, EventArgs e)
        {
            txtUser.SelectAll();
        }

        private void txtPass_Click(object sender, EventArgs e)
        {
            txtPass.SelectAll();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
          
            clsPlus second = new clsPlus();
            second.username = txtUser.Text;
            second.password = txtPass.Text;
            if (second.username.Trim() == "mark" && second.password.Trim() == "orcena")
            {
                MessageBox.Show("Welcome " + " " + second.username, "Enjoy!", MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information);
            }
            else {
                MessageBox.Show("Password or username is incorrect. " , "Login", MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error);
            }

        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            clsPlus first = new clsPlus();
            txtUser.Focus();
        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {
            txtPass.PasswordChar = '*';
        }
    }
}
