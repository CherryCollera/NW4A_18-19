﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PalaposVillaruz_Lab004
{
    class ColorChoice
    {
        public static readonly Color MyColor;
        static ColorChoice()
        {

            DateTime currentDate = DateTime.Now;

            //Checking the Weekend as it is Saturday or Sunday  
            if (currentDate.DayOfWeek == DayOfWeek.Saturday || currentDate.DayOfWeek == DayOfWeek.Sunday)
            {
                //If the Current Date is Saturday or Sunday  
                //then set the readonly field 'MyColor' to Blue  
                MyColor = Color.Blue;
            }

            //Days Other than Weekends(i.e other than Staurday or Sunday)  
            else
            {
                //If it is not weekend  
                //set the field 'MyColor' to Black  
                MyColor = Color.Black;
            }
        }
    }
}
