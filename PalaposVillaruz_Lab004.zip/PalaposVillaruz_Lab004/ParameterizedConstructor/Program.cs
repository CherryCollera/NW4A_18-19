﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParameterizedConstructor
{
    class Program
    {
         static void Main(string[] args)
        {
            int firstnum = 0;
            int secondnum= 0;
         
            Sample s = new Sample(firstnum, secondnum);

            Console.Write("Enter First Number " + "\t");
            s.firstnum = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number " + "\t");
            s.secondnum = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Sum = {0}", s.firstnum + s.secondnum);
            Console.WriteLine("Difference = {0}", s.firstnum - s.secondnum);
            Console.WriteLine("Product = {0}", s.firstnum * s.secondnum);

            try
            {
                Console.WriteLine("Quotient= {0}", s.firstnum / s.secondnum);
            }

            catch (DivideByZeroException ex) {
                Console.Error.WriteLine(ex.Message);
            }
            
            try
            {
                Console.WriteLine("Remainder = {0}", s.firstnum % s.secondnum);
            }

            catch (DivideByZeroException ex)
            {
                Console.Error.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}