﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParameterizedConstructor
{
    class Sample
    {
        public int firstnum, secondnum;
        public Sample(int fn, int sn) {

            firstnum = fn;
            secondnum = sn;
        }
    }
}
