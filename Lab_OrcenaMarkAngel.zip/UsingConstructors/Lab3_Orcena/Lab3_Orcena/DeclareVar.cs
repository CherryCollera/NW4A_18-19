﻿/*
 * Created by SharpDevelop.
 * User: Jezreel
 * Date: 10/5/2018
 * Time: 12:48 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Lab3_Orcena
{
	/// <summary>
	/// Description of DeclareVar.
	/// </summary>
	public class DeclareVar
	{
		public static double total1 = 0;
		public static double total2=0;
		public static bool minusButtonClicked = false;
		public static bool plusButtonClicked = false;
		public static bool multiplyButtonClicked = false;
		public static bool divideButtonClicked = false;
		public static bool equalsButtonClicked = false;
	}
}
