﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlusOne__StaticConstructor__Group_
{
    class clsPlus
    {
        public string username, password;
        static clsPlus()
        {
            System.Windows.Forms.MessageBox.Show("The right username is \"mark\" \n password is \"orcena\"", "Log-in", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information);
       
        }

        public clsPlus()
        {
            frmLogin forms = new frmLogin();
            username = forms.txtUser.Text;
            password = forms.txtPass.Text;
        }
    }
}
