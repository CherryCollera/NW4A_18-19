﻿namespace PlusOne_Static_Constructor
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.laboratoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lab4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usingDefaultConstructorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usingCopyConstructorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usingToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.usingPrivateConstructorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.plusOneStaticConstructorGroupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(628, 24);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.laboratoriesToolStripMenuItem});
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.openToolStripMenuItem.Text = "Open";
            // 
            // laboratoriesToolStripMenuItem
            // 
            this.laboratoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lab1ToolStripMenuItem,
            this.lab2ToolStripMenuItem,
            this.lab3ToolStripMenuItem,
            this.lab4ToolStripMenuItem});
            this.laboratoriesToolStripMenuItem.Name = "laboratoriesToolStripMenuItem";
            this.laboratoriesToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.laboratoriesToolStripMenuItem.Text = "Laboratories";
            // 
            // lab1ToolStripMenuItem
            // 
            this.lab1ToolStripMenuItem.Name = "lab1ToolStripMenuItem";
            this.lab1ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.lab1ToolStripMenuItem.Text = "Lab_1";
            // 
            // lab2ToolStripMenuItem
            // 
            this.lab2ToolStripMenuItem.Name = "lab2ToolStripMenuItem";
            this.lab2ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.lab2ToolStripMenuItem.Text = "Lab_2";
            // 
            // lab3ToolStripMenuItem
            // 
            this.lab3ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calculatorToolStripMenuItem});
            this.lab3ToolStripMenuItem.Name = "lab3ToolStripMenuItem";
            this.lab3ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.lab3ToolStripMenuItem.Text = "Lab_3";
            // 
            // calculatorToolStripMenuItem
            // 
            this.calculatorToolStripMenuItem.Name = "calculatorToolStripMenuItem";
            this.calculatorToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.calculatorToolStripMenuItem.Text = "Calculator";
            this.calculatorToolStripMenuItem.Click += new System.EventHandler(this.calculatorToolStripMenuItem_Click);
            // 
            // lab4ToolStripMenuItem
            // 
            this.lab4ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usingDefaultConstructorToolStripMenuItem,
            this.usingToolStripMenuItem,
            this.usingCopyConstructorToolStripMenuItem,
            this.usingToolStripMenuItem1,
            this.usingPrivateConstructorToolStripMenuItem,
            this.plusOneStaticConstructorGroupToolStripMenuItem});
            this.lab4ToolStripMenuItem.Name = "lab4ToolStripMenuItem";
            this.lab4ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.lab4ToolStripMenuItem.Text = "Lab_4";
            // 
            // usingDefaultConstructorToolStripMenuItem
            // 
            this.usingDefaultConstructorToolStripMenuItem.Name = "usingDefaultConstructorToolStripMenuItem";
            this.usingDefaultConstructorToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.usingDefaultConstructorToolStripMenuItem.Text = "Using Default Constructor";
            this.usingDefaultConstructorToolStripMenuItem.Click += new System.EventHandler(this.usingDefaultConstructorToolStripMenuItem_Click);
            // 
            // usingToolStripMenuItem
            // 
            this.usingToolStripMenuItem.Name = "usingToolStripMenuItem";
            this.usingToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.usingToolStripMenuItem.Text = "Using Parametrized Constructor";
            this.usingToolStripMenuItem.Click += new System.EventHandler(this.usingToolStripMenuItem_Click);
            // 
            // usingCopyConstructorToolStripMenuItem
            // 
            this.usingCopyConstructorToolStripMenuItem.Name = "usingCopyConstructorToolStripMenuItem";
            this.usingCopyConstructorToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.usingCopyConstructorToolStripMenuItem.Text = "Using Copy Constructor";
            this.usingCopyConstructorToolStripMenuItem.Click += new System.EventHandler(this.usingCopyConstructorToolStripMenuItem_Click);
            // 
            // usingToolStripMenuItem1
            // 
            this.usingToolStripMenuItem1.Name = "usingToolStripMenuItem1";
            this.usingToolStripMenuItem1.Size = new System.Drawing.Size(262, 22);
            this.usingToolStripMenuItem1.Text = "Using Static Constructor";
            this.usingToolStripMenuItem1.Click += new System.EventHandler(this.usingToolStripMenuItem1_Click);
            // 
            // usingPrivateConstructorToolStripMenuItem
            // 
            this.usingPrivateConstructorToolStripMenuItem.Name = "usingPrivateConstructorToolStripMenuItem";
            this.usingPrivateConstructorToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.usingPrivateConstructorToolStripMenuItem.Text = "Using Private Constructor";
            this.usingPrivateConstructorToolStripMenuItem.Click += new System.EventHandler(this.usingPrivateConstructorToolStripMenuItem_Click);
            // 
            // plusOneStaticConstructorGroupToolStripMenuItem
            // 
            this.plusOneStaticConstructorGroupToolStripMenuItem.Name = "plusOneStaticConstructorGroupToolStripMenuItem";
            this.plusOneStaticConstructorGroupToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.plusOneStaticConstructorGroupToolStripMenuItem.Text = "PlusOne(Static Constructor)(Group)";
            this.plusOneStaticConstructorGroupToolStripMenuItem.Click += new System.EventHandler(this.plusOneStaticConstructorGroupToolStripMenuItem_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.Location = new System.Drawing.Point(0, 27);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(628, 320);
            this.pnlMain.TabIndex = 9;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(628, 347);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "Lab4_NW4A";
            this.Load += new System.EventHandler(this.frmPlus_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem laboratoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lab1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lab2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lab3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lab4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usingDefaultConstructorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usingCopyConstructorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usingToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem usingPrivateConstructorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem plusOneStaticConstructorGroupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculatorToolStripMenuItem;
        public System.Windows.Forms.Panel pnlMain;
    }
}

