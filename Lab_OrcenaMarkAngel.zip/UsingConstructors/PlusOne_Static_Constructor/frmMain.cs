﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PlusOne_Static_Constructor
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmPlus_Load(object sender, EventArgs e)
        {

           
        }

        private void usingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UsingParmeterizedConstructors.frmParameter para = new UsingParmeterizedConstructors.frmParameter();
            para.TopLevel = false;
            pnlMain.Controls.Add(para);
            para.Show();
        }

        private void usingDefaultConstructorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UsingDefaultConstructors.frmDefault defaults= new UsingDefaultConstructors.frmDefault();
            defaults.TopLevel = false;
            pnlMain.Controls.Add(defaults);
            defaults.Show();
        }

        private void usingCopyConstructorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UsingCopyConstructors.frmCopy copy = new UsingCopyConstructors.frmCopy();
            copy.TopLevel = false;
            pnlMain.Controls.Add(copy);
            copy.Show();
        }

        private void usingToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            UsingStaticConstructors.frmStatic statics = new UsingStaticConstructors.frmStatic();
            statics.TopLevel = false;
            pnlMain.Controls.Add(statics);
            statics.Show();
        }

        private void usingPrivateConstructorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UsingPrivateConstructor.frmPrivate privates = new UsingPrivateConstructor.frmPrivate();
            privates.TopLevel = false;
            pnlMain.Controls.Add(privates);
            privates.Show();
        }

        private void plusOneStaticConstructorGroupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PlusOne__StaticConstructor__Group_.frmLogin plus = new PlusOne__StaticConstructor__Group_.frmLogin();
            plus.TopLevel = false;
            pnlMain.Controls.Add(plus);
            plus.Show();
        }

        private void calculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lab3_Orcena.Calculator calc = new Lab3_Orcena.Calculator();
            calc.TopLevel = false;
            pnlMain.Controls.Add(calc);
            calc.Show();
        }
    }
}
