﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Constructor_Overloading
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Bryan";
            lastname = "Yandoc";
        }
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
        }
    }
}
