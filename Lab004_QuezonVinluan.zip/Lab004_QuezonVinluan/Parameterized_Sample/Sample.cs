﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parameterized_Sample
{
    class Sample
    {
        public string fname, lname;
        public Sample(string x, string y)
        {
            fname = x;
            lname = y;
        }
    }
}
