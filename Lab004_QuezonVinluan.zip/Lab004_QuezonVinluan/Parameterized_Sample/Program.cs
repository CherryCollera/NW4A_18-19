﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parameterized_Sample
{
    class Program
    {
        private static void Main(string[] args)
        {
            Sample s = new Sample("Darryl", "Quezon");

            Console.WriteLine(s.fname);
            Console.WriteLine(s.lname);
            Console.ReadLine();
        }
    }
}
