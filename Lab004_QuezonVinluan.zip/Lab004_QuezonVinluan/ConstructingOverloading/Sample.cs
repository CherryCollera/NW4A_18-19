﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorOverloading_Sample
{
    class Sample
    {
        public string fname, lname;
        public Sample()
        {
            fname = "Darryl";
            lname = "Quezon";
        }

        public Sample(string x, string y)
        {
            fname = x;
            lname = y;
        }
    }
}
