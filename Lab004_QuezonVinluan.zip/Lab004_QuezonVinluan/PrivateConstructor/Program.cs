﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructor
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Sample s = new Sample(0, 0);

            Console.Write("Enter First Number:");
            s.a = Convert.ToInt32(Console.ReadLine());
            
            Console.Write("Enter Second Number:");
            s.b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("sum= {2} ", s.a, s.b, s.a + s.b);
            Console.WriteLine("difference= {2} ", s.a, s.b, s.a - s.b);
            Console.WriteLine("product = {2} ", s.a, s.b, s.a * s.b);

            try { Console.WriteLine("quotient = {2} ", s.a, s.b, s.a / s.b);

            }
            catch (DivideByZeroException e){Console.Error.WriteLine("Error:" + e.Message);

            }
            try
            {
                Console.WriteLine("remainder = {2} ", s.a, s.b, s.a % s.b);
            }
            catch (DivideByZeroException e)
            {
                Console.Error.WriteLine("Error:" + e.Message);
            }
                Console.ReadKey();
        }
    }
}
