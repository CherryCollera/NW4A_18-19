﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructor
{
    class Sample
    {
        public int a, b;
        public Sample (int aa, int bb)
        {
           a = aa;
           b = bb;
        }
        private Sample()

        {
        }      

    }
}
