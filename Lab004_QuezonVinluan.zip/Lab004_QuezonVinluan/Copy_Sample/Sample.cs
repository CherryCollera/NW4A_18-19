﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Copy_Sample
{
    class Sample
    {
        public string fname, lname;
        public Sample (string x, string y)

        {
            fname = x;
            lname = y;
        }
        public Sample(Sample s)
        {
            fname = s.fname;
            lname = s.lname;
        }
    }
}
