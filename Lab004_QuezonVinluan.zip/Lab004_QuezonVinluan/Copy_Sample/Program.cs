﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Copy_Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s = new Sample("Darryl", "Quezon");
            Sample s1 = new Sample(s);
            Console.WriteLine(s);
            Console.WriteLine("\n" + s1.fname + "\n\n" + s1.lname);
            Console.ReadLine();
        }
    }
}
