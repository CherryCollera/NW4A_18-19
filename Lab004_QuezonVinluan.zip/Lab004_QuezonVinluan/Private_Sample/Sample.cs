﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Private_Sample
{
    class Sample
    {
        public string fname, lname;
        public Sample(string x, string y)

        {
            fname = x;
            lname = y;
        }
            private Sample()
        {
            System.Console.WriteLine("Private Constructor with no paremeters");
            Console.ReadLine();
        }

    }
}
